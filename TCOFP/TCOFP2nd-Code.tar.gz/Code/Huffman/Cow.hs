module Cow where

import Bee

fish = honeyEater
